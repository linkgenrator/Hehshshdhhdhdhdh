import { useMemo, useState } from 'react';
import { Search, Copy, Check, ExternalLink, Download, FileCode, Files } from 'lucide-react';
import type { CopyFormat, GeneratedLink } from '@/types';
import { formatLink } from '@/lib/naming';

interface LinkResultsProps {
  links: GeneratedLink[];
  owner: string;
}

const FORMAT_LABELS: Record<CopyFormat, string> = {
  url: 'URL',
  html: 'HTML',
  markdown: 'Markdown',
};

export function LinkResults({ links, owner }: LinkResultsProps) {
  const [search, setSearch] = useState('');
  const [format, setFormat] = useState<CopyFormat>('url');
  const [copiedAll, setCopiedAll] = useState(false);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);
  const [showAll, setShowAll] = useState(false);
  const [companionOnly, setCompanionOnly] = useState(false);

  const filtered = useMemo(() => {
    let result = links;
    if (companionOnly) {
      result = result.filter((l) => l.isCompanion);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        (l) => l.url.toLowerCase().includes(q) || l.path.toLowerCase().includes(q) || l.repo.toLowerCase().includes(q),
      );
    }
    return result;
  }, [links, search, companionOnly]);

  const visible = showAll ? filtered : filtered.slice(0, 100);

  const copyAll = () => {
    const text = filtered.map((l) => formatLink(l.url, format, l.path)).join('\n');
    navigator.clipboard.writeText(text);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2000);
  };

  const copyOne = (idx: number) => {
    const link = filtered[idx];
    navigator.clipboard.writeText(formatLink(link.url, format, link.path));
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  const download = () => {
    const text = links.map((l) => formatLink(l.url, format, l.path)).join('\n');
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cdn-links-${format}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search links by repo, file, or URL..."
            className="w-full pl-9 pr-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400/30 transition-colors placeholder:text-slate-600"
          />
        </div>
        <button
          onClick={() => setCompanionOnly((v) => !v)}
          className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 border ${
            companionOnly
              ? 'bg-sky-500/15 text-sky-300 border-sky-500/30'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800 border-slate-700'
          }`}
        >
          <Files className="w-3.5 h-3.5" />
          Companion only
        </button>
        <div className="flex rounded-lg border border-slate-700 overflow-hidden">
          {(Object.keys(FORMAT_LABELS) as CopyFormat[]).map((f) => (
            <button
              key={f}
              onClick={() => setFormat(f)}
              className={`px-3 py-2 text-xs font-medium transition-colors ${
                format === f ? 'bg-emerald-500/15 text-emerald-300' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {FORMAT_LABELS[f]}
            </button>
          ))}
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-wrap gap-2">
        <button onClick={copyAll} className="px-4 py-2 rounded-lg bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/25 transition-colors flex items-center gap-2 text-sm font-medium">
          {copiedAll ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          Copy {filtered.length > 0 ? filtered.length.toLocaleString() : ''} {format === 'url' ? 'links' : format === 'html' ? 'img tags' : 'markdown'}
        </button>
        <button onClick={download} className="px-4 py-2 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 transition-colors flex items-center gap-2 text-sm font-medium">
          <Download className="w-4 h-4" />
          Download .txt
        </button>
      </div>

      {/* Link list */}
      <div className="space-y-1.5 max-h-[500px] overflow-y-auto rounded-xl border border-slate-800 p-2">
        {visible.length === 0 ? (
          <p className="text-center text-sm text-slate-500 py-8">No links match your search.</p>
        ) : (
          visible.map((link, i) => {
            const actualIdx = filtered.indexOf(link);
            return (
              <div key={i} className="group flex items-center gap-2 p-2.5 rounded-lg bg-slate-900/50 hover:bg-slate-900 border border-slate-800/50 transition-colors">
                {link.isCompanion && (
                  <span className="shrink-0 px-1.5 py-0.5 rounded bg-sky-500/15 text-sky-300 text-[10px] font-medium flex items-center gap-1">
                    <FileCode className="w-2.5 h-2.5" />
                    companion
                  </span>
                )}
                <code className={`flex-1 text-xs truncate font-mono ${link.isCompanion ? 'text-sky-300' : 'text-slate-300'}`}>
                  {format === 'url' ? link.url : formatLink(link.url, format, link.path)}
                </code>
                <button onClick={() => copyOne(actualIdx)} className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded hover:bg-slate-700">
                  {copiedIdx === actualIdx ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                </button>
                <a href={link.url} target="_blank" rel="noreferrer" className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded hover:bg-slate-700">
                  <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                </a>
              </div>
            );
          })
        )}
        {!showAll && filtered.length > 100 && (
          <button
            onClick={() => setShowAll(true)}
            className="w-full py-2 text-xs text-slate-400 hover:text-slate-200 transition-colors"
          >
            Show all {filtered.length.toLocaleString()} links
          </button>
        )}
        {showAll && filtered.length > 100 && (
          <button
            onClick={() => setShowAll(false)}
            className="w-full py-2 text-xs text-slate-400 hover:text-slate-200 transition-colors"
          >
            Show first 100
          </button>
        )}
      </div>
    </div>
  );
}
