import { useCallback, useRef, useState } from 'react';
import { Upload, FileCode, X, Plus, Files } from 'lucide-react';

interface FileUploadProps {
  file: File | null;
  companionFiles: File[];
  onFile: (file: File) => void;
  onCompanionAdd: (files: File[]) => void;
  onCompanionRemove: (index: number) => void;
  onClear: () => void;
}

export function FileUpload({ file, companionFiles, onFile, onCompanionAdd, onCompanionRemove, onClear }: FileUploadProps) {
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const companionInputRef = useRef<HTMLInputElement>(null);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const files = Array.from(e.dataTransfer.files ?? []);
    if (files.length > 0) onFile(files[0]);
  }, [onFile]);

  return (
    <div className="space-y-4">
      {/* Primary file drop zone */}
      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        onClick={() => !file && inputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-all ${
          file
            ? 'border-emerald-500/40 bg-emerald-500/5 cursor-default'
            : 'border-slate-700 hover:border-slate-600 hover:bg-slate-900/50 cursor-pointer'
        } ${dragOver ? 'border-emerald-400 bg-emerald-500/10' : ''}`}
      >
        <input
          ref={inputRef}
          type="file"
          className="hidden"
          onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); e.target.value = ''; }}
        />
        {file ? (
          <div className="flex items-center justify-center gap-3">
            <div className="w-12 h-12 rounded-lg bg-emerald-500/15 flex items-center justify-center">
              <FileCode className="w-7 h-7 text-emerald-400" />
            </div>
            <div className="text-left">
              <p className="font-medium text-slate-100">{file.name}</p>
              <p className="text-xs text-slate-500">{(file.size / 1024).toFixed(1)} KB · {file.type || 'unknown type'}</p>
            </div>
            <button
              onClick={(e) => { e.stopPropagation(); onClear(); }}
              className="ml-2 p-1.5 rounded-lg hover:bg-slate-700 text-slate-500 hover:text-slate-300 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div>
            <div className="w-14 h-14 mx-auto mb-3 rounded-full bg-slate-800 flex items-center justify-center">
              <Upload className="w-7 h-7 text-slate-500" />
            </div>
            <p className="text-slate-400">Drop your primary file here or click to browse</p>
            <p className="text-xs text-slate-600 mt-1">This file gets duplicated with numeric naming (index.svg, index1.svg, ...)</p>
          </div>
        )}
      </div>

      {/* Companion files */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
            <Files className="w-3.5 h-3.5 text-slate-500" />
            Companion files {companionFiles.length > 0 && `(${companionFiles.length})`}
          </span>
          <button
            onClick={() => companionInputRef.current?.click()}
            className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            Add files
          </button>
          <input
            ref={companionInputRef}
            type="file"
            multiple
            className="hidden"
            onChange={(e) => {
              const files = Array.from(e.target.files ?? []);
              if (files.length > 0) onCompanionAdd(files);
              e.target.value = '';
            }}
          />
        </div>
        <p className="text-xs text-slate-600 mb-2">
          Extra files pushed as-is to every repo (e.g. sw.js, manifest.json, styles.css) — keeps companion links working
        </p>
        {companionFiles.length > 0 ? (
          <div className="space-y-1.5">
            {companionFiles.map((cf, i) => (
              <div key={i} className="flex items-center gap-3 p-2.5 rounded-lg bg-slate-900/60 border border-slate-800">
                <div className="w-8 h-8 rounded bg-slate-800 flex items-center justify-center shrink-0">
                  <FileCode className="w-4 h-4 text-slate-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-slate-200 truncate">{cf.name}</p>
                  <p className="text-xs text-slate-500">{(cf.size / 1024).toFixed(1)} KB</p>
                </div>
                <button
                  onClick={() => onCompanionRemove(i)}
                  className="p-1.5 rounded-lg hover:bg-slate-700 text-slate-500 hover:text-slate-300 transition-colors shrink-0"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-3 rounded-lg border border-dashed border-slate-800 text-center">
            <p className="text-xs text-slate-600">No companion files added</p>
          </div>
        )}
      </div>
    </div>
  );
}
