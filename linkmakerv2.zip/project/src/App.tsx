import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Link2,
  Zap,
  AlertCircle,
  Hash,
  Settings2,
  Layers,
  Gauge,
  ChevronDown,
  ChevronUp,
  Clock,
  Trash2,
  RotateCcw,
  Github,
  Check,
} from 'lucide-react';
import type { CDNType, CopyFormat, GeneratedLink, GenerationConfig, GenerationProgress, GitHubUser, RateLimitState, RepoResult } from '@/types';
import {
  CDN_OPTIONS,
  estimateApiCalls,
  estimateDuration,
  estimateLinks,
  parseSubwords,
  sanitizeWord,
} from '@/lib/naming';
import { fetchRateLimit, generateLinks, validateToken } from '@/lib/generator';
import { clearToken, clearUser, loadConfig, loadToken, loadUser, saveConfig, saveToken, saveUser } from '@/lib/storage';
import { FileUpload } from '@/components/FileUpload';
import { TokenConnect } from '@/components/TokenConnect';
import { ProgressView } from '@/components/ProgressView';
import { LinkResults } from '@/components/LinkResults';

type Step = 'config' | 'token' | 'running' | 'done';

const DEFAULT_CONFIG: GenerationConfig = {
  mainWord: 'index',
  subwords: [],
  copiesPerName: 100,
  numRepos: 5,
  repoPrefix: 'autorepo',
  cdnType: 'jsdelivr',
  concurrency: 5,
};

const STEP_LABELS: Record<Step, string> = {
  config: 'Configure',
  token: 'Connect',
  running: 'Generate',
  done: 'Results',
};

const inputClass = 'w-full px-3.5 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400/30 transition-colors placeholder:text-slate-600';

export default function App() {
  const [step, setStep] = useState<Step>('config');
  const [config, setConfig] = useState<GenerationConfig>(() => {
    const saved = loadConfig();
    return { ...DEFAULT_CONFIG, ...saved };
  });
  const [file, setFile] = useState<File | null>(null);
  const [companionFiles, setCompanionFiles] = useState<File[]>([]);
  const [token, setToken] = useState(() => loadToken());
  const [user, setUser] = useState<GitHubUser | null>(() => loadUser());
  const [tokenValid, setTokenValid] = useState(() => !!loadUser());
  const [tokenError, setTokenError] = useState('');
  const [validating, setValidating] = useState(false);

  const [progress, setProgress] = useState<GenerationProgress | null>(null);
  const [repoResults, setRepoResults] = useState<RepoResult[]>([]);
  const [links, setLinks] = useState<GeneratedLink[]>([]);
  const [error, setError] = useState('');
  const [showRepos, setShowRepos] = useState(false);
  const [liveQuota, setLiveQuota] = useState<RateLimitState | null>(null);
  const [checkingQuota, setCheckingQuota] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  const estLinks = useMemo(() => estimateLinks(config), [config]);
  const estCalls = useMemo(() => estimateApiCalls(config, companionFiles.length), [config, companionFiles.length]);
  const estTime = useMemo(() => estimateDuration({ ...config, subwords: config.subwords } as any), [config]);

  useEffect(() => {
    saveConfig(config);
  }, [config]);

  const handleFile = useCallback((f: File) => {
    setFile(f);
    setConfig((c) => {
      if (!c.mainWord || c.mainWord === 'index') {
        const base = f.name.replace(/\.[^.]+$/, '');
        return { ...c, mainWord: sanitizeWord(base) || 'index' };
      }
      return c;
    });
  }, []);

  const handleCompanionAdd = useCallback((files: File[]) => {
    setCompanionFiles((prev) => {
      const existing = new Set(prev.map((f) => f.name));
      const newFiles = files.filter((f) => !existing.has(f.name));
      return [...prev, ...newFiles];
    });
  }, []);

  const handleCompanionRemove = useCallback((index: number) => {
    setCompanionFiles((prev) => prev.filter((_, i) => i !== index));
  }, []);

  const handleValidateToken = useCallback(async () => {
    if (!token.trim()) return;
    setValidating(true);
    setTokenError('');
    try {
      const u = await validateToken(token.trim());
      setUser(u);
      setTokenValid(true);
      saveToken(token.trim());
      saveUser(u);
    } catch (e: any) {
      setTokenValid(false);
      setTokenError(e.message ?? 'Failed to validate token');
    } finally {
      setValidating(false);
    }
  }, [token]);

  const handleTokenChange = useCallback((t: string) => {
    setToken(t);
    setTokenValid(false);
    setTokenError('');
  }, []);

  const handleGenerate = useCallback(async () => {
    if (!file || !tokenValid) return;
    const controller = new AbortController();
    abortRef.current = controller;

    setStep('running');
    setError('');
    setLinks([]);
    setProgress(null);
    setRepoResults(
      Array.from({ length: config.numRepos }, (_, i) => ({
        repoName: `${config.repoPrefix}${i + 1}`,
        commitSha: null,
        fileCount: 0,
        status: 'pending' as const,
      })),
    );

    const subwords = parseSubwords(config.subwords.join(','));

    try {
      const { links: generatedLinks, result } = await generateLinks({
        file,
        companionFiles,
        config: { ...config, subwords },
        token: token.trim(),
        signal: controller.signal,
        onProgress: (p) => setProgress(p),
        onRepoStatus: (repoName, status, err) => {
          setRepoResults((prev) => {
            const idx = prev.findIndex((r) => r.repoName === repoName);
            if (idx < 0) return prev;
            const next = [...prev];
            next[idx] = { ...next[idx], status, error: err };
            return next;
          });
        },
      });
      setLinks(generatedLinks);
      setRepoResults(result.repoResults);
      setStep('done');
    } catch (e: any) {
      if (e.name === 'AbortError') {
        setStep('token');
      } else {
        setError(e.message ?? 'Generation failed');
        setStep('token');
      }
    } finally {
      abortRef.current = null;
    }
  }, [file, companionFiles, token, tokenValid, config]);

  const handleCancel = useCallback(() => {
    abortRef.current?.abort();
  }, []);

  const handleReset = useCallback(() => {
    setStep('config');
    setLinks([]);
    setRepoResults([]);
    setProgress(null);
    setError('');
  }, []);

  const handleClearFile = useCallback(() => {
    setFile(null);
    setCompanionFiles([]);
  }, []);

  const handleDisconnect = useCallback(() => {
    setToken('');
    setTokenValid(false);
    setUser(null);
    setLiveQuota(null);
    clearToken();
    clearUser();
  }, []);

  const handleCheckQuota = useCallback(async () => {
    if (!token.trim()) return;
    setCheckingQuota(true);
    try {
      const state = await fetchRateLimit(token.trim());
      setLiveQuota(state);
    } catch {
      setLiveQuota(null);
    } finally {
      setCheckingQuota(false);
    }
  }, [token]);

  useEffect(() => {
    if (tokenValid) {
      handleCheckQuota();
    }
  }, [tokenValid, handleCheckQuota]);

  const doneRepos = repoResults.filter((r) => r.status === 'done').length;
  const errorRepos = repoResults.filter((r) => r.status === 'error').length;
  const allWords = [config.mainWord, ...config.subwords].filter((w) => w.length > 0);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      {/* Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -left-40 w-[600px] h-[600px] bg-emerald-500/8 rounded-full blur-[140px]" />
        <div className="absolute top-1/4 -right-40 w-[500px] h-[500px] bg-sky-500/8 rounded-full blur-[140px]" />
        <div className="absolute bottom-0 left-1/3 w-[400px] h-[400px] bg-teal-500/5 rounded-full blur-[120px]" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        {/* Header */}
        <header className="mb-10 flex items-start justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <Link2 className="w-7 h-7 text-slate-950" strokeWidth={2.5} />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">CDN Link Forge</h1>
              <p className="text-sm text-slate-400">Auto-publish duplicated files to GitHub for instant CDN links</p>
            </div>
          </div>
          {tokenValid && user && (
            <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-900/60 border border-slate-800">
              <img src={user.avatar_url} alt="" className="w-6 h-6 rounded-full" />
              <span className="text-sm text-slate-300">{user.login}</span>
              <button onClick={handleDisconnect} className="ml-1 text-xs text-slate-500 hover:text-red-400 transition-colors">
                Disconnect
              </button>
            </div>
          )}
        </header>

        {/* Step indicator */}
        <div className="flex items-center gap-2 mb-8 text-sm overflow-x-auto pb-1">
          {(['config', 'token', 'running', 'done'] as Step[]).map((s, i) => {
            const active = step === s || (step === 'done' && s === 'running');
            const passed = (['config', 'token', 'running', 'done'] as Step[]).indexOf(step) > i;
            return (
              <div key={s} className="flex items-center gap-2 shrink-0">
                <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg transition-colors ${
                  active ? 'bg-emerald-500/15 text-emerald-300' : passed ? 'text-slate-400' : 'text-slate-600'
                }`}>
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-semibold ${
                    active ? 'bg-emerald-400 text-slate-950' : passed ? 'bg-slate-700 text-slate-300' : 'bg-slate-800 text-slate-600'
                  }`}>{i + 1}</span>
                  <span className="hidden sm:inline">{STEP_LABELS[s]}</span>
                </div>
                {i < 3 && <div className={`w-6 h-px ${passed ? 'bg-slate-600' : 'bg-slate-800'}`} />}
              </div>
            );
          })}
        </div>

        {/* Step 1: Config */}
        {step === 'config' && (
          <div className="space-y-6">
            <Card icon={<Hash className="w-5 h-5" />} title="Upload Files" subtitle="Primary file gets duplicated; companion files are pushed as-is">
              <div className="mt-4">
                <FileUpload
                  file={file}
                  companionFiles={companionFiles}
                  onFile={handleFile}
                  onCompanionAdd={handleCompanionAdd}
                  onCompanionRemove={handleCompanionRemove}
                  onClear={handleClearFile}
                />
              </div>
            </Card>

            <Card icon={<Hash className="w-5 h-5" />} title="Link Naming" subtitle="Main word + subwords drive the numeric file names">
              <div className="mt-4 grid sm:grid-cols-2 gap-4">
                <Field label="Main word">
                  <input
                    type="text"
                    value={config.mainWord}
                    onChange={(e) => setConfig((c) => ({ ...c, mainWord: sanitizeWord(e.target.value) }))}
                    placeholder="index"
                    className={inputClass}
                  />
                </Field>
                <Field label="Subwords (comma-separated)">
                  <input
                    type="text"
                    value={config.subwords.join(', ')}
                    onChange={(e) => setConfig((c) => ({ ...c, subwords: parseSubwords(e.target.value) }))}
                    placeholder="logo, banner, icon"
                    className={inputClass}
                  />
                </Field>
              </div>
              <div className="mt-3 p-3 rounded-lg bg-slate-900/60 border border-slate-800">
                <p className="text-xs text-slate-400 mb-1.5">Preview file names ({allWords.length} words × {config.copiesPerName} copies = {(allWords.length * config.copiesPerName).toLocaleString()} files per repo):</p>
                <div className="flex flex-wrap gap-1.5">
                  {allWords.slice(0, 5).map((w, i) => (
                    <span key={i} className="px-2 py-0.5 rounded bg-slate-800 text-xs text-emerald-300 font-mono">
                      {w}.svg, {w}1.svg, {w}2.svg...
                    </span>
                  ))}
                  {allWords.length > 5 && (
                    <span className="px-2 py-0.5 text-xs text-slate-500">+{allWords.length - 5} more</span>
                  )}
                </div>
              </div>
            </Card>

            <Card icon={<Settings2 className="w-5 h-5" />} title="Generation Settings" subtitle="Control how many repos and copies are created">
              <div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <Field label="Copies per name">
                  <NumberInput value={config.copiesPerName} min={1} max={10000} onChange={(v) => setConfig((c) => ({ ...c, copiesPerName: v }))} />
                </Field>
                <Field label="Number of repos">
                  <NumberInput value={config.numRepos} min={1} max={500} onChange={(v) => setConfig((c) => ({ ...c, numRepos: v }))} />
                </Field>
                <Field label="Repo prefix">
                  <input
                    type="text"
                    value={config.repoPrefix}
                    onChange={(e) => setConfig((c) => ({ ...c, repoPrefix: sanitizeWord(e.target.value) || 'autorepo' }))}
                    className={inputClass}
                  />
                </Field>
                <Field label="Parallel uploads (1-10)">
                  <NumberInput value={config.concurrency} min={1} max={10} onChange={(v) => setConfig((c) => ({ ...c, concurrency: v }))} />
                </Field>
                <Field label="CDN provider">
                  <div className="relative">
                    <select
                      value={config.cdnType}
                      onChange={(e) => setConfig((c) => ({ ...c, cdnType: e.target.value as CDNType }))}
                      className={`${inputClass} appearance-none pr-9`}
                    >
                      {CDN_OPTIONS.map((o) => (
                        <option key={o.value} value={o.value} className="bg-slate-900">{o.label}</option>
                      ))}
                    </select>
                    <ChevronDown className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
                  </div>
                </Field>
                <div className="flex items-end">
                  <p className="text-xs text-slate-500 pb-2">
                    {CDN_OPTIONS.find((c) => c.value === config.cdnType)?.description}
                  </p>
                </div>
              </div>

              <div className="mt-4 grid grid-cols-3 gap-3">
                <EstimateCard icon={<Layers className="w-4 h-4" />} label="Links" value={estLinks.toLocaleString()} />
                <EstimateCard icon={<Gauge className="w-4 h-4" />} label="API calls" value={estCalls.toLocaleString()} />
                <EstimateCard icon={<Clock className="w-4 h-4" />} label="Est. time" value={estTime} />
              </div>
              {estCalls > 4500 && (
                <div className="mt-3 flex items-start gap-2 p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 text-sm">
                  <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                  <span>This will use ~{estCalls.toLocaleString()} GitHub API calls. The default rate limit is 5,000/hour. The app auto-retries on rate limits, but consider reducing copies or repos for speed.</span>
                </div>
              )}
            </Card>

            <button
              onClick={() => setStep('token')}
              disabled={!file}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-500 text-slate-950 font-semibold transition-all hover:shadow-lg hover:shadow-emerald-500/20 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Continue to GitHub Connect
            </button>
          </div>
        )}

        {/* Step 2: Token */}
        {step === 'token' && (
          <div className="space-y-6">
            <Card icon={<Github className="w-5 h-5" />} title="Connect GitHub" subtitle="Your token creates repos and pushes files directly from your browser">
              <div className="mt-4">
                <TokenConnect
                  token={token}
                  onTokenChange={handleTokenChange}
                  onValidate={handleValidateToken}
                  validating={validating}
                  tokenValid={tokenValid}
                  tokenError={tokenError}
                  user={user}
                  onBack={() => setStep('config')}
                />
              </div>
            </Card>

            {tokenValid && (
              <Card icon={<Zap className="w-5 h-5" />} title="Ready to Generate" subtitle="Review your configuration before starting">
                <div className="mt-4 grid sm:grid-cols-2 gap-x-6 gap-y-1 text-sm">
                  <SummaryRow label="Primary file" value={file?.name ?? '—'} />
                  <SummaryRow label="Companion files" value={companionFiles.length > 0 ? companionFiles.map((f) => f.name).join(', ') : 'none'} />
                  <SummaryRow label="CDN" value={CDN_OPTIONS.find((c) => c.value === config.cdnType)?.label ?? ''} />
                  <SummaryRow label="Words" value={allWords.join(', ')} />
                  <SummaryRow label="Copies per name" value={config.copiesPerName.toLocaleString()} />
                  <SummaryRow label="Repos" value={config.numRepos.toLocaleString()} />
                  <SummaryRow label="Parallel" value={`${config.concurrency} workers`} />
                  <SummaryRow label="Total links" value={estLinks.toLocaleString()} accent />
                  <SummaryRow label="Est. time" value={estTime} />
                </div>

                {/* Live quota check */}
                <div className="mt-4 p-4 rounded-xl bg-slate-900/60 border border-slate-800">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
                      <Gauge className="w-3.5 h-3.5 text-emerald-400" />
                      GitHub API Quota
                    </span>
                    <button onClick={handleCheckQuota} disabled={checkingQuota} className="text-xs text-slate-500 hover:text-slate-300 transition-colors disabled:opacity-40">
                      {checkingQuota ? 'Checking...' : 'Refresh'}
                    </button>
                  </div>
                  {liveQuota ? (
                    <>
                      <div className="h-2 rounded-full bg-slate-800 overflow-hidden mb-2">
                        <div
                          className={`h-full transition-all ${
                            liveQuota.remaining < 100 ? 'bg-red-400'
                              : liveQuota.remaining < 500 ? 'bg-amber-400'
                              : liveQuota.remaining < estCalls ? 'bg-orange-400'
                              : 'bg-emerald-400'
                          }`
                          }
                          style={{ width: `${(liveQuota.remaining / liveQuota.total) * 100}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-400 font-mono">{liveQuota.remaining.toLocaleString()} / {liveQuota.total.toLocaleString()} remaining</span>
                        <span className="text-slate-500 font-mono">need ~{estCalls.toLocaleString()}</span>
                      </div>
                      {liveQuota.remaining < estCalls && (
                        <div className="mt-2 flex items-start gap-2 text-xs text-red-400">
                          <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                          <span>Not enough quota for this generation. You need ~{estCalls.toLocaleString()} calls but only have {liveQuota.remaining.toLocaleString()}. Wait for reset or reduce the number of repos/copies.</span>
                        </div>
                      )}
                      {liveQuota.remaining >= estCalls && liveQuota.remaining < estCalls + 50 && (
                        <div className="mt-2 flex items-start gap-2 text-xs text-amber-400">
                          <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                          <span>Tight margin — only {liveQuota.remaining - estCalls} calls to spare after this generation.</span>
                        </div>
                      )}
                    </>
                  ) : (
                    <p className="text-xs text-slate-500">{checkingQuota ? 'Checking quota...' : 'Unable to fetch quota. The app will still check before and during generation.'}</p>
                  )}
                </div>

                <button
                  onClick={handleGenerate}
                  className="mt-5 w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-500 text-slate-950 font-semibold transition-all hover:shadow-lg hover:shadow-emerald-500/20 flex items-center justify-center gap-2"
                >
                  <Zap className="w-5 h-5" />
                  Generate {estLinks.toLocaleString()} Links
                </button>
              </Card>
            )}
          </div>
        )}

        {/* Step 3: Running */}
        {step === 'running' && (
          <Card icon={<Zap className="w-5 h-5 text-emerald-400 animate-pulse" />} title="Generating Links..." subtitle="Creating repos and pushing files in parallel">
            <div className="mt-5">
              <ProgressView
                results={repoResults}
                totalRepos={config.numRepos}
                progress={progress}
                onCancel={handleCancel}
              />
            </div>
          </Card>
        )}

        {/* Step 4: Done */}
        {step === 'done' && (
          <div className="space-y-6">
            {error && (
              <div className="flex items-center gap-2 p-4 rounded-lg bg-red-500/10 border border-red-500/30 text-red-300">
                <AlertCircle className="w-5 h-5 shrink-0" />
                {error}
              </div>
            )}

            <div className="rounded-2xl bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 p-5 sm:p-6">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div>
                  <h2 className="text-xl font-bold text-slate-100">Generation Complete</h2>
                  <p className="text-sm text-slate-400 mt-0.5">
                    {links.length.toLocaleString()} links generated across {doneRepos} repos
                    {errorRepos > 0 && <span className="text-red-400"> ({errorRepos} failed)</span>}
                  </p>
                </div>
                <button onClick={handleReset} className="px-4 py-2 rounded-lg border border-slate-700 text-slate-300 hover:text-slate-100 hover:border-slate-600 transition-colors flex items-center gap-2 text-sm font-medium">
                  <RotateCcw className="w-4 h-4" />
                  Start New
                </button>
              </div>
            </div>

            <Card icon={<Link2 className="w-5 h-5" />} title="Generated Links" subtitle={`${links.length.toLocaleString()} CDN links ready to copy`}>
              <div className="mt-4">
                <LinkResults links={links} owner={user?.login ?? ''} />
              </div>
            </Card>

            <Card icon={<Layers className="w-5 h-5" />} title="Repository Details" subtitle={`${repoResults.length} repos created`}>
              <button onClick={() => setShowRepos((v) => !v)} className="mt-4 w-full flex items-center justify-between text-sm text-slate-400 hover:text-slate-200 transition-colors">
                <span>{doneRepos} succeeded, {errorRepos} failed, {repoResults.length - doneRepos - errorRepos} other</span>
                {showRepos ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              {showRepos && (
                <div className="mt-3 space-y-1.5">
                  {repoResults.map((r) => (
                    <div key={r.repoName} className="flex items-center gap-3 p-2.5 rounded-lg bg-slate-900/50 border border-slate-800">
                      {r.status === 'done' ? (
                        <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-mono text-slate-300">{r.repoName}</p>
                        {r.commitSha && <p className="text-xs text-slate-500 font-mono truncate">{r.commitSha.slice(0, 7)} · {r.fileCount.toLocaleString()} files</p>}
                        {r.error && <p className="text-xs text-red-400 truncate">{r.error}</p>}
                      </div>
                      {r.status === 'done' && (
                        <a href={`https://github.com/${user?.login}/${r.repoName}`} target="_blank" rel="noreferrer" className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1 shrink-0">
                          View <ChevronDown className="w-3 h-3 -rotate-90" />
                        </a>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>
        )}

        <footer className="mt-12 text-center text-xs text-slate-600 space-y-1">
          <p>All operations happen in your browser. Your GitHub token is never sent to any server.</p>
          <p className="flex items-center justify-center gap-1.5">
            <Trash2 className="w-3 h-3" /> Token & settings saved locally — disconnect to clear
          </p>
        </footer>
      </div>
    </div>
  );
}

// --- UI primitives ---

function Card({ icon, title, subtitle, children }: { icon: React.ReactNode; title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl bg-slate-900/60 backdrop-blur border border-slate-800 p-5 sm:p-6">
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center text-emerald-400 shrink-0">{icon}</div>
        <div className="flex-1">
          <h2 className="font-semibold text-slate-100">{title}</h2>
          <p className="text-sm text-slate-400">{subtitle}</p>
        </div>
      </div>
      {children}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-medium text-slate-400 mb-1.5">{label}</label>
      {children}
    </div>
  );
}

function NumberInput({ value, min, max, onChange }: { value: number; min: number; max: number; onChange: (v: number) => void }) {
  return (
    <input
      type="number"
      value={value}
      min={min}
      max={max}
      onChange={(e) => {
        const v = parseInt(e.target.value, 10);
        if (!isNaN(v)) onChange(Math.max(min, Math.min(max, v)));
      }}
      className={inputClass}
    />
  );
}

function EstimateCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3 p-3 rounded-lg bg-slate-900/60 border border-slate-800">
      <div className="text-emerald-400">{icon}</div>
      <div>
        <p className="text-xs text-slate-500">{label}</p>
        <p className="text-lg font-semibold text-slate-100">{value}</p>
      </div>
    </div>
  );
}

function SummaryRow({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-slate-800 last:border-0">
      <span className="text-slate-400">{label}</span>
      <span className={`font-medium ${accent ? 'text-emerald-300' : 'text-slate-200'}`}>{value}</span>
    </div>
  );
}
