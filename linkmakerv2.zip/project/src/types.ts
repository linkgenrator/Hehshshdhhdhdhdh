export interface GitHubUser {
  login: string;
  name: string | null;
  avatar_url: string;
  public_repos: number;
}

export type CDNType = 'jsdelivr' | 'esm' | 'esm-cdn' | 'gcore' | 'statically' | 'raw';

export type CopyFormat = 'url' | 'html' | 'markdown';

export interface GenerationConfig {
  mainWord: string;
  subwords: string[];
  copiesPerName: number;
  numRepos: number;
  repoPrefix: string;
  cdnType: CDNType;
  concurrency: number;
}

export type RepoStatus = 'pending' | 'creating-repo' | 'uploading' | 'committing' | 'done' | 'error' | 'paused';

export interface RepoResult {
  repoName: string;
  commitSha: string | null;
  fileCount: number;
  status: RepoStatus;
  error?: string;
}

export interface RepoFile {
  path: string;
  contentBase64: string;
}

export interface GeneratedLink {
  url: string;
  repo: string;
  path: string;
  isCompanion: boolean;
}

export type QuotaLevel = 'ok' | 'warning' | 'critical' | 'exhausted';

export interface RateLimitState {
  remaining: number;
  total: number;
  resetEpoch: number;
  used: number;
}

export interface GenerationProgress {
  totalRepos: number;
  completedRepos: number;
  totalLinks: number;
  rateLimitRemaining: number;
  rateLimitTotal: number;
  rateLimitResetEpoch: number;
  phase: string;
  quotaLevel: QuotaLevel;
  quotaMessage?: string;
  paused: boolean;
}

export interface CallContext {
  token: string;
  signal?: AbortSignal;
  onRateLimit?: (state: RateLimitState) => void;
  checkQuota?: (needed: number) => Promise<void>;
}

export interface GenerationResult {
  fileNames: string[];
  companionNames: string[];
  repoResults: RepoResult[];
  owner: string;
}
