import type {
  CallContext,
  CDNType,
  GeneratedLink,
  GenerationConfig,
  GenerationProgress,
  GenerationResult,
  QuotaLevel,
  RateLimitState,
  RepoResult,
} from '@/types';
import { asyncPool } from '@/lib/concurrency';
import {
  estimateCallsPerRepo,
  fetchRateLimit,
  fileToBase64,
  processRepo,
  validateToken,
} from '@/lib/github';
import {
  generateFileNames,
  generateLink,
  getFileExtension,
} from '@/lib/naming';

export interface GenerateOptions {
  file: File;
  config: GenerationConfig;
  token: string;
  signal?: AbortSignal;
  onProgress?: (progress: GenerationProgress) => void;
  onRepoStatus?: (repoName: string, status: RepoResult['status'], error?: string) => void;
  onRateLimit?: (state: RateLimitState) => void;
}

const SAFETY_MARGIN = 50;

function classifyQuota(remaining: number, total: number, needed: number): QuotaLevel {
  if (remaining <= 0) return 'exhausted';
  if (remaining < needed) return 'exhausted';
  if (remaining < needed + SAFETY_MARGIN) return 'critical';
  if (remaining < total * 0.2) return 'warning';
  return 'ok';
}

function formatResetCountdown(resetEpoch: number): string {
  if (!resetEpoch) return 'unknown';
  const ms = resetEpoch * 1000 - Date.now();
  if (ms <= 0) return 'resetting now';
  const mins = Math.floor(ms / 60_000);
  const secs = Math.round((ms % 60_000) / 1000);
  if (mins > 0) return `resets in ${mins}m ${secs}s`;
  return `resets in ${secs}s`;
}

export async function generateLinks(opts: GenerateOptions): Promise<{
  links: GeneratedLink[];
  result: GenerationResult;
}> {
  const { file, config, token, signal, onProgress, onRepoStatus, onRateLimit } = opts;

  const user = await validateToken(token);
  const owner = user.login;

  const extension = getFileExtension(file.name);
  const fileNames = generateFileNames(
    config.mainWord,
    config.subwords,
    config.copiesPerName,
    extension,
  );

  const contentBase64 = await fileToBase64(file);

  const callsPerRepo = estimateCallsPerRepo(fileNames.length);
  const totalEstimatedCalls = callsPerRepo * config.numRepos;

  // Pre-flight: fetch current rate limit
  let rateState: RateLimitState;
  try {
    rateState = await fetchRateLimit(token);
  } catch {
    rateState = { remaining: 5000, total: 5000, resetEpoch: 0, used: 0 };
  }

  onRateLimit?.(rateState);

  const preFlightLevel = classifyQuota(rateState.remaining, rateState.total, totalEstimatedCalls);
  if (preFlightLevel === 'exhausted') {
    const msg = `Not enough GitHub API quota. You need ~${totalEstimatedCalls.toLocaleString()} calls but only have ${rateState.remaining.toLocaleString()} remaining (${formatResetCountdown(rateState.resetEpoch)}).`;
    throw new Error(msg);
  }

  const repoNames: string[] = [];
  for (let i = 1; i <= config.numRepos; i++) {
    repoNames.push(`${config.repoPrefix}${i}`);
  }

  const repoResults: RepoResult[] = repoNames.map((name) => ({
    repoName: name,
    commitSha: null,
    fileCount: 0,
    status: 'pending',
  }));

  let lastRateState = rateState;

  const ctx: CallContext = {
    token,
    signal,
    onRateLimit: (state) => {
      lastRateState = state;
      onRateLimit?.(state);
      onProgress?.({
        totalRepos: config.numRepos,
        completedRepos: repoResults.filter((r) => r.status === 'done').length,
        totalLinks: repoResults
          .filter((r) => r.status === 'done')
          .reduce((sum, r) => sum + r.fileCount, 0),
        rateLimitRemaining: state.remaining,
        rateLimitTotal: state.total,
        rateLimitResetEpoch: state.resetEpoch,
        phase: 'Processing repos',
        quotaLevel: classifyQuota(state.remaining, state.total, callsPerRepo),
        quotaMessage: undefined,
        paused: false,
      });
    },
  };

  async function ensureQuota(needed: number): Promise<void> {
    let state = lastRateState;
    const level = classifyQuota(state.remaining, state.total, needed);

    if (level === 'exhausted' || level === 'critical') {
      // Try to get fresh state
      try {
        state = await fetchRateLimit(token);
        lastRateState = state;
        onRateLimit?.(state);
      } catch {
        // use cached state
      }

      const freshLevel = classifyQuota(state.remaining, state.total, needed);
      if (freshLevel === 'exhausted') {
        if (state.resetEpoch > 0) {
          const waitMs = (state.resetEpoch * 1000) - Date.now();
          if (waitMs > 0 && waitMs < 3_600_000) {
            onProgress?.({
              totalRepos: config.numRepos,
              completedRepos: repoResults.filter((r) => r.status === 'done').length,
              totalLinks: repoResults
                .filter((r) => r.status === 'done')
                .reduce((sum, r) => sum + r.fileCount, 0),
              rateLimitRemaining: state.remaining,
              rateLimitTotal: state.total,
              rateLimitResetEpoch: state.resetEpoch,
              phase: `Quota exhausted — ${formatResetCountdown(state.resetEpoch)}`,
              quotaLevel: 'exhausted',
              quotaMessage: `Waiting for quota reset (${formatResetCountdown(state.resetEpoch)}). Generation will resume automatically.`,
              paused: true,
            });

            await sleep(waitMs + 2000, signal);

            // Re-check after waiting
            try {
              state = await fetchRateLimit(token);
              lastRateState = state;
              onRateLimit?.(state);
            } catch {
              // proceed with cached state
            }

            const afterLevel = classifyQuota(state.remaining, state.total, needed);
            if (afterLevel === 'exhausted') {
              throw new Error(
                `GitHub API quota exhausted. Needed ${needed} calls but only ${state.remaining.toLocaleString()} available. ${formatResetCountdown(state.resetEpoch)}.`,
              );
            }
          } else {
            throw new Error(
              `GitHub API quota exhausted. Needed ${needed} calls but only ${state.remaining.toLocaleString()} available. ${formatResetCountdown(state.resetEpoch)}.`,
            );
          }
        } else {
          throw new Error(
            `GitHub API quota exhausted. Needed ${needed} calls but only ${state.remaining.toLocaleString()} available.`,
          );
        }
      }
    }
  }

  ctx.checkQuota = ensureQuota;

  await asyncPool(
    repoNames,
    async (repoName) => {
      const idx = repoResults.findIndex((r) => r.repoName === repoName);
      if (idx < 0) return;

      try {
        await ensureQuota(callsPerRepo);

        const result = await processRepo(
          ctx,
          owner,
          repoName,
          fileNames,
          contentBase64,
          {
            onPhase: (phase) => {
              repoResults[idx].status = phase;
              onRepoStatus?.(repoName, phase);
            },
          },
        );

        repoResults[idx].commitSha = result.commitSha;
        repoResults[idx].fileCount = result.fileCount;
        repoResults[idx].status = 'done';
        onRepoStatus?.(repoName, 'done');
      } catch (e: any) {
        if (e.name === 'AbortError') {
          repoResults[idx].status = 'pending';
          onRepoStatus?.(repoName, 'pending');
          throw e;
        }
        repoResults[idx].status = 'error';
        repoResults[idx].error = e.message ?? 'Unknown error';
        onRepoStatus?.(repoName, 'error', repoResults[idx].error);
      }

      onProgress?.({
        totalRepos: config.numRepos,
        completedRepos: repoResults.filter((r) => r.status === 'done').length,
        totalLinks: repoResults
          .filter((r) => r.status === 'done')
          .reduce((sum, r) => sum + r.fileCount, 0),
        rateLimitRemaining: lastRateState.remaining,
        rateLimitTotal: lastRateState.total,
        rateLimitResetEpoch: lastRateState.resetEpoch,
        phase: 'Processing repos',
        quotaLevel: classifyQuota(lastRateState.remaining, lastRateState.total, callsPerRepo),
        quotaMessage: undefined,
        paused: false,
      });
    },
    {
      concurrency: config.concurrency,
      signal,
    },
  );

  const links: GeneratedLink[] = [];
  for (const repo of repoResults) {
    if (repo.status !== 'done' || !repo.commitSha) continue;
    for (const path of fileNames) {
      links.push({
        url: generateLink(config.cdnType, owner, repo.repoName, repo.commitSha, path),
        repo: repo.repoName,
        path,
      });
    }
  }

  return {
    links,
    result: { fileNames, repoResults, owner },
  };
}

function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, ms);
    signal?.addEventListener('abort', () => {
      clearTimeout(timer);
      reject(new DOMException('Aborted', 'AbortError'));
    }, { once: true });
  });
}

export { validateToken, fetchRateLimit };
export type { CDNType };
