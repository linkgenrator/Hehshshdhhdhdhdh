import type { CallContext, GitHubUser, RateLimitState } from '@/types';

const API = 'https://api.github.com';

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, ms);
    signal?.addEventListener('abort', () => {
      clearTimeout(timer);
      reject(new DOMException('Aborted', 'AbortError'));
    }, { once: true });
  });
}

function parseRateLimitHeaders(res: Response): RateLimitState | null {
  const remaining = parseInt(res.headers.get('X-RateLimit-Remaining') ?? '', 10);
  const total = parseInt(res.headers.get('X-RateLimit-Limit') ?? '', 10);
  const resetEpoch = parseInt(res.headers.get('X-RateLimit-Reset') ?? '', 10);
  if (isNaN(remaining) || isNaN(total)) return null;
  return {
    remaining,
    total,
    resetEpoch: isNaN(resetEpoch) ? 0 : resetEpoch,
    used: total - remaining,
  };
}

async function ghFetch(
  ctx: CallContext,
  path: string,
  options: RequestInit = {},
): Promise<Response> {
  const res = await fetch(`${API}${path}`, {
    ...options,
    signal: ctx.signal,
    headers: {
      Authorization: `Bearer ${ctx.token}`,
      Accept: 'application/vnd.github+json',
      'Content-Type': 'application/json',
      'X-GitHub-Api-Version': '2022-11-28',
      ...options.headers,
    },
  });

  const state = parseRateLimitHeaders(res);
  if (state) ctx.onRateLimit?.(state);

  return res;
}

const MAX_RETRIES = 3;

async function ghJson(
  ctx: CallContext,
  path: string,
  options: RequestInit = {},
): Promise<any> {
  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    if (ctx.signal?.aborted) throw new DOMException('Aborted', 'AbortError');

    let res: Response;
    try {
      res = await ghFetch(ctx, path, options);
    } catch (e: any) {
      if (e.name === 'AbortError') throw e;
      lastError = e;
      if (attempt < MAX_RETRIES) {
        await sleep(1000 * Math.pow(2, attempt), ctx.signal);
        continue;
      }
      throw e;
    }

    if (res.ok) {
      if (res.status === 204) return null;
      return res.json();
    }

    // Rate limit
    if (res.status === 403 || res.status === 429) {
      const remaining = parseInt(res.headers.get('X-RateLimit-Remaining') ?? '1', 10);
      const resetEpoch = parseInt(res.headers.get('X-RateLimit-Reset') ?? '0', 10);
      const retryAfter = res.headers.get('Retry-After');

      if (remaining === 0 && resetEpoch) {
        const waitMs = Math.max(1000, (resetEpoch * 1000) - Date.now());
        if (attempt < MAX_RETRIES && waitMs < 600_000) {
          await sleep(waitMs, ctx.signal);
          continue;
        }
      }

      if (retryAfter) {
        const waitMs = parseInt(retryAfter, 10) * 1000;
        if (attempt < MAX_RETRIES && waitMs < 600_000) {
          await sleep(waitMs, ctx.signal);
          continue;
        }
      }

      // Secondary rate limit — back off
      if (attempt < MAX_RETRIES) {
        await sleep(2000 * Math.pow(2, attempt), ctx.signal);
        continue;
      }
    }

    // 5xx — retry
    if (res.status >= 500 && attempt < MAX_RETRIES) {
      await sleep(1000 * Math.pow(2, attempt), ctx.signal);
      continue;
    }

    // Non-retryable error
    let msg = `GitHub API error (${res.status})`;
    try {
      const e = await res.json();
      msg = e.message ?? msg;
    } catch {
      // ignore parse error
    }
    const err = new Error(msg) as Error & { status?: number };
    err.status = res.status;
    throw err;
  }

  throw lastError ?? new Error('Max retries exceeded');
}

export async function validateToken(token: string): Promise<GitHubUser> {
  const res = await fetch(`${API}/user`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
    },
  });
  if (!res.ok) {
    throw new Error(
      res.status === 401
        ? 'Invalid or expired token'
        : `Failed to verify token (${res.status})`,
    );
  }
  const data = await res.json();
  return {
    login: data.login,
    name: data.name,
    avatar_url: data.avatar_url,
    public_repos: data.public_repos,
  };
}

export async function fetchRateLimit(token: string): Promise<RateLimitState> {
  const res = await fetch(`${API}/rate_limit`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
    },
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch rate limit (${res.status})`);
  }
  const data = await res.json();
  const core = data.resources?.core ?? data.rate;
  return {
    remaining: core.remaining,
    total: core.limit,
    resetEpoch: core.reset,
    used: core.used ?? (core.limit - core.remaining),
  };
}

export async function createRepo(ctx: CallContext, name: string): Promise<void> {
  try {
    await ghJson(ctx, '/user/repos', {
      method: 'POST',
      body: JSON.stringify({ name, private: false, auto_init: true }),
    });
  } catch (e: any) {
    if (e.status === 422 || e.message?.toLowerCase().includes('already exists')) {
      return;
    }
    throw e;
  }
}

export async function getMainBranch(
  ctx: CallContext,
  owner: string,
  repo: string,
): Promise<{ sha: string; branch: string } | null> {
  for (const branch of ['main', 'master']) {
    try {
      const data = await ghJson(ctx, `/repos/${owner}/${repo}/git/refs/heads/${branch}`);
      return { sha: data.object.sha, branch };
    } catch {
      // try next branch
    }
  }
  return null;
}

export async function createBlob(
  ctx: CallContext,
  owner: string,
  repo: string,
  contentBase64: string,
): Promise<string> {
  const data = await ghJson(ctx, `/repos/${owner}/${repo}/git/blobs`, {
    method: 'POST',
    body: JSON.stringify({ content: contentBase64, encoding: 'base64' }),
  });
  return data.sha;
}

export async function createTree(
  ctx: CallContext,
  owner: string,
  repo: string,
  entries: { path: string; mode: string; type: string; sha: string }[],
  baseTreeSha?: string,
): Promise<string> {
  const data = await ghJson(ctx, `/repos/${owner}/${repo}/git/trees`, {
    method: 'POST',
    body: JSON.stringify({ base_tree: baseTreeSha, tree: entries }),
  });
  return data.sha;
}

export async function createCommit(
  ctx: CallContext,
  owner: string,
  repo: string,
  message: string,
  treeSha: string,
  parentSha: string | null,
): Promise<string> {
  const body: Record<string, unknown> = { message, tree: treeSha };
  if (parentSha) body.parents = [parentSha];
  const data = await ghJson(ctx, `/repos/${owner}/${repo}/git/commits`, {
    method: 'POST',
    body: JSON.stringify(body),
  });
  return data.sha;
}

export async function updateRef(
  ctx: CallContext,
  owner: string,
  repo: string,
  ref: string,
  sha: string,
): Promise<void> {
  await ghJson(ctx, `/repos/${owner}/${repo}/git/refs/${ref}`, {
    method: 'PATCH',
    body: JSON.stringify({ sha }),
  });
}

export async function createRef(
  ctx: CallContext,
  owner: string,
  repo: string,
  ref: string,
  sha: string,
): Promise<void> {
  await ghJson(ctx, `/repos/${owner}/${repo}/git/refs`, {
    method: 'POST',
    body: JSON.stringify({ ref: `refs/${ref}`, sha }),
  });
}

const TREE_CHUNK_SIZE = 5000;

export interface ProcessRepoCallbacks {
  onPhase?: (phase: 'creating-repo' | 'uploading' | 'committing') => void;
}

export async function processRepo(
  ctx: CallContext,
  owner: string,
  repoName: string,
  fileNames: string[],
  contentBase64: string,
  callbacks?: ProcessRepoCallbacks,
): Promise<{ repoName: string; commitSha: string; fileCount: number }> {
  callbacks?.onPhase?.('creating-repo');
  await createRepo(ctx, repoName);

  const branch = await getMainBranch(ctx, owner, repoName);

  callbacks?.onPhase?.('uploading');
  const blobSha = await createBlob(ctx, owner, repoName, contentBase64);

  let treeSha: string | undefined;
  for (let i = 0; i < fileNames.length; i += TREE_CHUNK_SIZE) {
    const chunk = fileNames.slice(i, i + TREE_CHUNK_SIZE);
    const entries = chunk.map((path) => ({
      path,
      mode: '100644',
      type: 'blob',
      sha: blobSha,
    }));
    treeSha = await createTree(ctx, owner, repoName, entries, treeSha);
  }

  callbacks?.onPhase?.('committing');
  const commitSha = await createCommit(
    ctx,
    owner,
    repoName,
    'Add files via CDN Link Forge',
    treeSha!,
    branch?.sha ?? null,
  );

  if (branch) {
    await updateRef(ctx, owner, repoName, `heads/${branch.branch}`, commitSha);
  } else {
    await createRef(ctx, owner, repoName, 'heads/main', commitSha);
  }

  return { repoName, commitSha, fileCount: fileNames.length };
}

export function estimateCallsPerRepo(fileCount: number): number {
  const treeChunks = Math.ceil(fileCount / TREE_CHUNK_SIZE);
  return 5 + treeChunks;
}
