export interface AsyncPoolOptions {
  concurrency: number;
  signal?: AbortSignal;
  onProgress?: (completed: number, total: number) => void;
}

export async function asyncPool<T>(
  items: T[],
  worker: (item: T, index: number) => Promise<void>,
  options: AsyncPoolOptions,
): Promise<void> {
  let nextIndex = 0;
  let completed = 0;
  const total = items.length;
  const concurrency = Math.max(1, Math.min(options.concurrency, total || 1));

  async function run(): Promise<void> {
    while (nextIndex < total) {
      if (options.signal?.aborted) return;
      const index = nextIndex++;
      await worker(items[index], index);
      completed++;
      options.onProgress?.(completed, total);
    }
  }

  const workers = Array.from({ length: concurrency }, () => run());
  await Promise.all(workers);

  if (options.signal?.aborted) {
    throw new DOMException('Aborted', 'AbortError');
  }
}
