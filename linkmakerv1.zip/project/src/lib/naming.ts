import type { CDNType, CopyFormat, GenerationConfig } from '@/types';

export const CDN_OPTIONS: { value: CDNType; label: string; prefix: string; description: string }[] = [
  { value: 'jsdelivr', label: 'cdn.jsdelivr.net', prefix: 'https://cdn.jsdelivr.net/gh', description: 'Open-source CDN, global edge network' },
  { value: 'esm', label: 'esm.sh', prefix: 'https://esm.sh/gh', description: 'ES module CDN with on-the-fly transforms' },
  { value: 'esm-cdn', label: 'cdn.esm.sh', prefix: 'https://cdn.esm.sh/gh', description: 'esm.sh dedicated CDN endpoint' },
  { value: 'gcore', label: 'gcore.com', prefix: 'https://cdn.gcore.com/gh', description: 'Gcore global CDN with edge caching' },
  { value: 'statically', label: 'cdn.statically.io', prefix: 'https://cdn.statically.io/gh', description: 'Statically CDN for static GitHub files' },
  { value: 'raw', label: 'raw.githubusercontent.com', prefix: 'https://raw.githubusercontent.com', description: 'GitHub raw content (no CDN caching)' },
];

export function getFileExtension(filename: string): string {
  const parts = filename.split('.');
  return parts.length > 1 ? parts.pop()! : 'svg';
}

export function isImageExtension(ext: string): boolean {
  return ['svg', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'ico'].includes(ext.toLowerCase());
}

export function sanitizeWord(word: string): string {
  return word.trim().replace(/[^a-zA-Z0-9_-]/g, '');
}

export function parseSubwords(input: string): string[] {
  return input
    .split(',')
    .map((s) => sanitizeWord(s))
    .filter((s) => s.length > 0);
}

export function generateFileNames(
  mainWord: string,
  subwords: string[],
  copies: number,
  extension: string,
): string[] {
  const names: string[] = [];
  const allWords = [sanitizeWord(mainWord), ...subwords].filter((w) => w.length > 0);

  for (const word of allWords) {
    names.push(`${word}.${extension}`);
    for (let i = 1; i < copies; i++) {
      names.push(`${word}${i}.${extension}`);
    }
  }

  return names;
}

export function generateLink(
  cdnType: CDNType,
  owner: string,
  repo: string,
  sha: string,
  path: string,
): string {
  const cdn = CDN_OPTIONS.find((c) => c.value === cdnType)!;
  if (cdnType === 'raw') {
    return `${cdn.prefix}/${owner}/${repo}/${sha}/${path}`;
  }
  return `${cdn.prefix}/${owner}/${repo}@${sha}/${path}`;
}

export function formatLink(url: string, format: CopyFormat, path: string): string {
  switch (format) {
    case 'html':
      return `<img src="${url}" alt="${path}" />`;
    case 'markdown':
      return `![${path}](${url})`;
    default:
      return url;
  }
}

export function estimateLinks(config: GenerationConfig): number {
  const wordCount = 1 + config.subwords.length;
  return wordCount * config.copiesPerName * config.numRepos;
}

export function estimateApiCalls(config: GenerationConfig): number {
  const filesPerRepo = (1 + config.subwords.length) * config.copiesPerName;
  const treeChunks = Math.ceil(filesPerRepo / 5000);
  const callsPerRepo = 5 + treeChunks;
  return callsPerRepo * config.numRepos;
}

export function estimateDuration(config: GenerationConfig): string {
  const calls = estimateApiCalls(config);
  const concurrency = Math.max(1, Math.min(config.concurrency, 10));
  const avgLatencyMs = 400;
  const ms = (calls / concurrency) * avgLatencyMs;
  if (ms < 1000) return '< 1s';
  if (ms < 60_000) return `${Math.round(ms / 1000)}s`;
  const mins = Math.floor(ms / 60_000);
  const secs = Math.round((ms % 60_000) / 1000);
  return `${mins}m ${secs}s`;
}
