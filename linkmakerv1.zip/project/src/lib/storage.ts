import type { GenerationConfig, GitHubUser } from '@/types';

const TOKEN_KEY = 'cdn-forge-token';
const CONFIG_KEY = 'cdn-forge-config';

export function saveToken(token: string): void {
  try {
    localStorage.setItem(TOKEN_KEY, token);
  } catch {
    // storage may be unavailable
  }
}

export function loadToken(): string {
  try {
    return localStorage.getItem(TOKEN_KEY) ?? '';
  } catch {
    return '';
  }
}

export function clearToken(): void {
  try {
    localStorage.removeItem(TOKEN_KEY);
  } catch {
    // ignore
  }
}

export function saveConfig(config: GenerationConfig): void {
  try {
    localStorage.setItem(CONFIG_KEY, JSON.stringify(config));
  } catch {
    // ignore
  }
}

export function loadConfig(): Partial<GenerationConfig> | null {
  try {
    const raw = localStorage.getItem(CONFIG_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function saveUser(user: GitHubUser): void {
  try {
    localStorage.setItem('cdn-forge-user', JSON.stringify(user));
  } catch {
    // ignore
  }
}

export function loadUser(): GitHubUser | null {
  try {
    const raw = localStorage.getItem('cdn-forge-user');
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function clearUser(): void {
  try {
    localStorage.removeItem('cdn-forge-user');
  } catch {
    // ignore
  }
}
