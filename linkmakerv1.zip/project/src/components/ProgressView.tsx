import { useEffect, useState } from 'react';
import { Loader2, Check, AlertCircle, X, Pause, Gauge, Clock } from 'lucide-react';
import type { GenerationProgress, RepoResult } from '@/types';

interface ProgressViewProps {
  results: RepoResult[];
  totalRepos: number;
  progress: GenerationProgress | null;
  onCancel: () => void;
}

const STATUS_LABELS: Record<RepoResult['status'], string> = {
  'pending': 'Queued',
  'creating-repo': 'Creating repo',
  'uploading': 'Uploading files',
  'committing': 'Committing',
  'done': 'Complete',
  'error': 'Failed',
  'paused': 'Paused',
};

export function ProgressView({ results, totalRepos, progress, onCancel }: ProgressViewProps) {
  const done = results.filter((r) => r.status === 'done').length;
  const errors = results.filter((r) => r.status === 'error').length;
  const active = results.filter((r) => r.status === 'creating-repo' || r.status === 'uploading' || r.status === 'committing').length;
  const pct = totalRepos > 0 ? (done / totalRepos) * 100 : 0;

  return (
    <div className="space-y-5">
      {/* Stats row */}
      <div className="grid grid-cols-4 gap-3">
        <StatBox label="Done" value={done} color="text-emerald-400" />
        <StatBox label="Active" value={active} color="text-amber-400" />
        <StatBox label="Queued" value={results.filter((r) => r.status === 'pending').length} color="text-slate-400" />
        <StatBox label="Failed" value={errors} color="text-red-400" />
      </div>

      {/* Quota warning banner */}
      {progress && progress.quotaLevel !== 'ok' && (
        <QuotaBanner
          level={progress.quotaLevel}
          message={progress.quotaMessage}
          remaining={progress.rateLimitRemaining}
          total={progress.rateLimitTotal}
          resetEpoch={progress.rateLimitResetEpoch}
          paused={progress.paused}
        />
      )}

      {/* Progress bar */}
      <div>
        <div className="flex justify-between text-sm mb-2">
          <span className="text-slate-400 flex items-center gap-2">
            {progress?.paused && <Pause className="w-3.5 h-3.5 text-amber-400" />}
            {progress?.phase ?? 'Processing repos...'}
          </span>
          <span className="text-emerald-300 font-medium font-mono">
            {done} / {totalRepos} · {pct.toFixed(0)}%
          </span>
        </div>
        <div className="h-3 rounded-full bg-slate-800 overflow-hidden">
          <div
            className={`h-full transition-all duration-500 relative overflow-hidden ${
              progress?.paused
                ? 'bg-gradient-to-r from-amber-400 to-orange-500'
                : 'bg-gradient-to-r from-emerald-400 to-teal-500'
            }`}
            style={{ width: `${pct}%` }}
          >
            {active > 0 && !progress?.paused && (
              <div className="absolute inset-0 bg-white/20 animate-pulse" />
            )}
          </div>
        </div>
      </div>

      {/* Rate limit bar */}
      {progress?.rateLimitTotal ? (
        <RateLimitBar
          remaining={progress.rateLimitRemaining}
          total={progress.rateLimitTotal}
          resetEpoch={progress.rateLimitResetEpoch}
        />
      ) : null}

      {/* Repo list */}
      <div className="space-y-1 max-h-64 overflow-y-auto rounded-xl border border-slate-800 p-2">
        {results.map((r) => (
          <div key={r.repoName} className="flex items-center gap-3 text-sm py-1.5 px-2 rounded-lg hover:bg-slate-900/50 transition-colors">
            <StatusIcon status={r.status} />
            <span className="font-mono text-xs text-slate-400 flex-shrink-0">{r.repoName}</span>
            <span className={`text-xs ${r.status === 'done' ? 'text-emerald-400/60' : r.status === 'error' ? 'text-red-400' : 'text-slate-500'}`}>
              {STATUS_LABELS[r.status]}
            </span>
            {r.commitSha && (
              <span className="text-xs text-slate-600 font-mono ml-auto">{r.commitSha.slice(0, 7)}</span>
            )}
            {r.error && (
              <span className="text-xs text-red-400 truncate ml-auto" title={r.error}>{r.error}</span>
            )}
          </div>
        ))}
      </div>

      {/* Cancel */}
      <button
        onClick={onCancel}
        className="w-full py-2.5 rounded-lg border border-red-500/30 text-red-400 hover:bg-red-500/10 transition-colors flex items-center justify-center gap-2 text-sm font-medium"
      >
        <X className="w-4 h-4" />
        Cancel Generation
      </button>
    </div>
  );
}

function QuotaBanner({
  level,
  message,
  remaining,
  total,
  resetEpoch,
  paused,
}: {
  level: string;
  message?: string;
  remaining: number;
  total: number;
  resetEpoch: number;
  paused: boolean;
}) {
  const [countdown, setCountdown] = useState('');

  useEffect(() => {
    if (!resetEpoch) return;
    const update = () => {
      const ms = resetEpoch * 1000 - Date.now();
      if (ms <= 0) {
        setCountdown('resetting now');
        return;
      }
      const mins = Math.floor(ms / 60_000);
      const secs = Math.round((ms % 60_000) / 1000);
      setCountdown(mins > 0 ? `${mins}m ${secs}s` : `${secs}s`);
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, [resetEpoch]);

  const isExhausted = level === 'exhausted';
  const isCritical = level === 'critical';
  const isWarning = level === 'warning';

  const bgClass = isExhausted
    ? 'bg-red-500/10 border-red-500/30 text-red-300'
    : isCritical
      ? 'bg-orange-500/10 border-orange-500/30 text-orange-300'
      : 'bg-amber-500/10 border-amber-500/30 text-amber-300';

  return (
    <div className={`flex items-start gap-3 p-4 rounded-xl border ${bgClass} animate-in fade-in`}>
      {paused ? (
        <Pause className="w-5 h-5 mt-0.5 shrink-0" />
      ) : isExhausted ? (
        <AlertCircle className="w-5 h-5 mt-0.5 shrink-0" />
      ) : (
        <Gauge className="w-5 h-5 mt-0.5 shrink-0" />
      )}
      <div className="flex-1">
        <p className="text-sm font-medium">
          {paused
            ? 'Generation paused — waiting for quota reset'
            : isExhausted
              ? 'GitHub quota exhausted'
              : isCritical
                ? 'Quota critically low'
                : 'Quota running low'}
        </p>
        <p className="text-xs mt-0.5 opacity-80">
          {message ?? `${remaining.toLocaleString()} of ${total.toLocaleString()} API calls remaining`}
          {countdown && <span className="ml-1.5 flex items-center gap-1"><Clock className="w-3 h-3" />resets in {countdown}</span>}
        </p>
      </div>
    </div>
  );
}

function RateLimitBar({ remaining, total, resetEpoch }: { remaining: number; total: number; resetEpoch: number }) {
  const pct = total > 0 ? (remaining / total) * 100 : 0;
  const colorClass = remaining < 100 ? 'bg-red-400' : remaining < 500 ? 'bg-amber-400' : 'bg-emerald-400';
  const [countdown, setCountdown] = useState('');

  useEffect(() => {
    if (!resetEpoch) return;
    const update = () => {
      const ms = resetEpoch * 1000 - Date.now();
      if (ms <= 0) {
        setCountdown('');
        return;
      }
      const mins = Math.floor(ms / 60_000);
      const secs = Math.round((ms % 60_000) / 1000);
      setCountdown(mins > 0 ? `${mins}m ${secs}s` : `${secs}s`);
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, [resetEpoch]);

  return (
    <div className="flex items-center gap-2 text-xs text-slate-500">
      <div className="flex-1 flex items-center gap-2">
        <span>GitHub quota</span>
        <div className="flex-1 h-1.5 rounded-full bg-slate-800 overflow-hidden max-w-[200px]">
          <div
            className={`h-full transition-all ${colorClass}`}
            style={{ width: `${pct}%` }}
          />
        </div>
        <span className="font-mono">{remaining.toLocaleString()} / {total.toLocaleString()}</span>
        {countdown && <span className="flex items-center gap-1 text-slate-600"><Clock className="w-3 h-3" />{countdown}</span>}
      </div>
    </div>
  );
}

function StatBox({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="text-center p-3 rounded-lg bg-slate-900/60 border border-slate-800">
      <p className={`text-2xl font-bold ${color}`}>{value}</p>
      <p className="text-xs text-slate-500 mt-0.5">{label}</p>
    </div>
  );
}

function StatusIcon({ status }: { status: RepoResult['status'] }) {
  switch (status) {
    case 'done':
      return <Check className="w-4 h-4 text-emerald-400 shrink-0" />;
    case 'error':
      return <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />;
    case 'pending':
      return <div className="w-4 h-4 rounded-full border-2 border-slate-700 shrink-0" />;
    case 'paused':
      return <Pause className="w-4 h-4 text-amber-400 shrink-0" />;
    default:
      return <Loader2 className="w-4 h-4 animate-spin text-amber-400 shrink-0" />;
  }
}
