import { useCallback, useRef, useState } from 'react';
import { Upload, FileCode, X } from 'lucide-react';

interface FileUploadProps {
  file: File | null;
  onFile: (file: File) => void;
  onClear: () => void;
}

export function FileUpload({ file, onFile, onClear }: FileUploadProps) {
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer.files?.[0];
    if (f) onFile(f);
  }, [onFile]);

  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
      onDragLeave={() => setDragOver(false)}
      onDrop={handleDrop}
      onClick={() => !file && inputRef.current?.click()}
      className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-all ${
        file
          ? 'border-emerald-500/40 bg-emerald-500/5 cursor-default'
          : 'border-slate-700 hover:border-slate-600 hover:bg-slate-900/50 cursor-pointer'
      } ${dragOver ? 'border-emerald-400 bg-emerald-500/10' : ''}`}
    >
      <input
        ref={inputRef}
        type="file"
        className="hidden"
        onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); }}
      />
      {file ? (
        <div className="flex items-center justify-center gap-3">
          <div className="w-12 h-12 rounded-lg bg-emerald-500/15 flex items-center justify-center">
            <FileCode className="w-7 h-7 text-emerald-400" />
          </div>
          <div className="text-left">
            <p className="font-medium text-slate-100">{file.name}</p>
            <p className="text-xs text-slate-500">{(file.size / 1024).toFixed(1)} KB · {file.type || 'unknown type'}</p>
          </div>
          <button
            onClick={(e) => { e.stopPropagation(); onClear(); }}
            className="ml-2 p-1.5 rounded-lg hover:bg-slate-700 text-slate-500 hover:text-slate-300 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <div>
          <div className="w-14 h-14 mx-auto mb-3 rounded-full bg-slate-800 flex items-center justify-center">
            <Upload className="w-7 h-7 text-slate-500" />
          </div>
          <p className="text-slate-400">Drop a file here or click to browse</p>
          <p className="text-xs text-slate-600 mt-1">SVG, JS, CSS, images — any file type</p>
        </div>
      )}
    </div>
  );
}
