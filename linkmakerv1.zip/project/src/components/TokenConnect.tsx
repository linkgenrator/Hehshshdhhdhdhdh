import { Github, Check, Loader2, AlertCircle, ExternalLink, Shield, Eye, EyeOff } from 'lucide-react';
import { useState } from 'react';
import type { GitHubUser } from '@/types';

interface TokenConnectProps {
  token: string;
  onTokenChange: (token: string) => void;
  onValidate: () => void;
  validating: boolean;
  tokenValid: boolean;
  tokenError: string;
  user: GitHubUser | null;
  onBack: () => void;
}

export function TokenConnect({
  token, onTokenChange, onValidate, validating, tokenValid, tokenError, user, onBack,
}: TokenConnectProps) {
  const [showToken, setShowToken] = useState(false);

  return (
    <div className="space-y-5">
      <div>
        <label className="block text-xs font-medium text-slate-400 mb-1.5">
          GitHub Personal Access Token
        </label>
        <div className="relative">
          <input
            type={showToken ? 'text' : 'password'}
            value={token}
            onChange={(e) => onTokenChange(e.target.value)}
            placeholder="github_pat_xxxxxxxxxxxx"
            className="w-full px-3.5 py-2.5 pr-20 rounded-lg bg-slate-900 border border-slate-700 text-slate-100 text-sm font-mono focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400/30 transition-colors placeholder:text-slate-600"
          />
          <button
            onClick={() => setShowToken((v) => !v)}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1.5 text-slate-500 hover:text-slate-300 transition-colors"
            type="button"
          >
            {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {tokenError && (
        <div className="flex items-center gap-2 text-sm text-red-400">
          <AlertCircle className="w-4 h-4 shrink-0" />
          {tokenError}
        </div>
      )}

      {tokenValid && user && (
        <div className="flex items-center gap-3 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 animate-in fade-in duration-300">
          <img src={user.avatar_url} alt="" className="w-10 h-10 rounded-full ring-2 ring-emerald-500/30" />
          <div className="flex-1">
            <p className="text-sm text-emerald-300 font-medium">Connected as {user.login}</p>
            <p className="text-xs text-slate-400">{user.public_repos} public repos</p>
          </div>
          <Check className="w-5 h-5 text-emerald-400" />
        </div>
      )}

      <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2.5">
        <div className="flex items-center gap-2 text-xs font-medium text-slate-300">
          <Shield className="w-3.5 h-3.5 text-emerald-400" />
          How to create a token
        </div>
        <ol className="text-xs text-slate-500 space-y-1.5 list-decimal list-inside">
          <li>Go to <span className="text-slate-300">GitHub Settings → Developer settings → Fine-grained personal access tokens</span></li>
          <li>Set expiration and create a token with <span className="text-slate-300">Contents: Read & Write</span> and <span className="text-slate-300">Administration: Read & Write</span></li>
          <li>Or use a classic token with <span className="text-slate-300">repo</span> scope</li>
        </ol>
        <a
          href="https://github.com/settings/tokens?type=beta"
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1 text-xs text-emerald-400 hover:text-emerald-300 transition-colors"
        >
          Open token settings <ExternalLink className="w-3 h-3" />
        </a>
      </div>

      <div className="flex items-center gap-2 text-xs text-slate-500">
        <Shield className="w-3.5 h-3.5 text-emerald-400/60" />
        Your token stays in your browser. All API calls go directly to GitHub — nothing is sent to any server.
      </div>

      <div className="flex gap-3">
        <button
          onClick={onValidate}
          disabled={!token.trim() || validating}
          className="px-5 py-2.5 rounded-lg bg-slate-800 text-slate-200 font-medium hover:bg-slate-700 transition-colors disabled:opacity-40 flex items-center gap-2"
        >
          {validating && <Loader2 className="w-4 h-4 animate-spin" />}
          {validating ? 'Checking...' : 'Validate Token'}
        </button>
        <button
          onClick={onBack}
          className="px-5 py-2.5 rounded-lg border border-slate-700 text-slate-400 hover:text-slate-200 hover:border-slate-600 transition-colors"
        >
          Back
        </button>
      </div>
    </div>
  );
}
